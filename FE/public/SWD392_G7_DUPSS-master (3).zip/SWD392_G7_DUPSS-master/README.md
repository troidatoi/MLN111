SRS: https://docs.google.com/document/d/1kwQQqFF3AydSLB2Sqd-Aiu0zBYAKMFPR/edit

Group activities: https://docs.google.com/document/d/1oWhotgymQ1sKPfAjed0-5oRmiZu8ALMXJgB3io5Bs3o/edit?tab=t.n5b9v37ga1q8
