function BlogPage() {
  return <div>BlogPage Page</div>;
}

export default BlogPage;
