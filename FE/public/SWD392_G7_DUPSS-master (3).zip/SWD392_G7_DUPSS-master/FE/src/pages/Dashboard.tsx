export default function Dashboard() {
  return <div> Đây là trang chính Dashboard</div>;
}
