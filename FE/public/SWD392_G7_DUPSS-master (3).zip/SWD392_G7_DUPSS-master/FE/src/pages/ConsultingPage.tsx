function ConsultingPage() {
  return <div>ConsultingPage</div>;
}

export default ConsultingPage;
