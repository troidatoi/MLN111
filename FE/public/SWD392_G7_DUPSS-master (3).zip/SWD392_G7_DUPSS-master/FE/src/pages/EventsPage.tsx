function EventsPage() {
  return <div>EventsPage</div>;
}

export default EventsPage;
