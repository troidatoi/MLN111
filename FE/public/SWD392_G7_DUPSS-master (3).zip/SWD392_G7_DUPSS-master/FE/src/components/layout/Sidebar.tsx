function Sidebar() {
  return (
    <aside className="h-screen w-64 bg-blue-900 text-white p-4">
      <h2 className="text-2xl font-bold mb-6">DUPS</h2>
      {/* Menu here */}
    </aside>
  );
}

export default Sidebar;
